<div class="preloader">
    <div class="preloader-container">
      <span class="animated-preloader"></span>
    </div> 
  </div> <?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/partials/preloader.blade.php ENDPATH**/ ?>