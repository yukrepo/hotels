<?php $__env->startSection('content'); ?>
    <!-- hotel deatils section start -->
    <section class="pb-100">
        <div class="hotel-details-thumb-slider">
            <div class="single-slide">
                <div class="hotel-details-thumb">
                    <a href="<?php echo e(getImage(imagePath()['property']['path'] . '/' . $property->image, imagePath()['property']['size'])); ?>"
                        class="lightcase full-view" data-rel="lightcase"><i class="las la-image"></i><?php echo app('translator')->get('See Full View'); ?>
                    </a>
                    <img src="<?php echo e(getImage(imagePath()['property']['path'] . '/' . $property->image, imagePath()['property']['size'])); ?>"
                        alt="image">
                </div>
            </div><!-- single-slide end -->
            <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-slide">
                    <div class="hotel-details-thumb">
                        <a href="<?php echo e(getImage(imagePath()['property']['path'] . '/' . $image, imagePath()['property']['size'])); ?>"
                            class="lightcase full-view" data-rel="lightcase"><i class="las la-image"></i><?php echo app('translator')->get('See Full
                            View'); ?>
                        </a>
                        <img src="<?php echo e(getImage(imagePath()['property']['path'] . '/' . $image, imagePath()['property']['size'])); ?>"
                            alt="image">
                    </div>
                </div><!-- single-slide end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- hotel-details-thumb-slider end -->
        <div class="container pt-50">
            <div class="row">
                <div class="col-lg-8">
                    <h2 class="as-title category-name">

                    </h2>
                    <div class="mt-5">
                        <h4 class="mb-3"><?php echo app('translator')->get('Amenities'); ?></h4>
                        <ul class="amenity-list">
                        </ul>
                    </div>

                    <div class="mt-5">
                        <div class="custom--card">
                            <div class="card-header">
                                <h4><?php echo app('translator')->get('Room List'); ?></h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive--md">
                                    <table class="table custom--table">
                                        <thead>
                                            <tr>
                                                <th><?php echo app('translator')->get('Room No.'); ?></th>
                                                <th><?php echo app('translator')->get('Adult'); ?></th>
                                                <th><?php echo app('translator')->get('Child'); ?></th>
                                                <th><?php echo app('translator')->get('Price'); ?></th>
                                                <th><?php echo app('translator')->get('Select'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody class="table-body">
                                            <?php $searchData = session()->get('search-data'); ?>
                                                <?php if(!$searchData || ($searchData && $searchData['date'] == null)): ?>
                                                    <p class="text-danger my-3"><?php echo app('translator')->get('** Select date to see available rooms.'); ?></p>
                                                <?php else: ?>
                                                <?php $__currentLoopData = $roomCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $category->rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(!$category->bookedRooms->where('room_id',$room->id)->first()): ?>
                                                            <tr class="category-item <?php echo e('category-'.$category->id); ?>">
                                                                <td data-label="<?php echo app('translator')->get('Room No.'); ?>" class="room_number">
                                                                <?php echo e(__($room->room_number)); ?>

                                                                </td>
                                                                <td data-label="<?php echo app('translator')->get('Adult'); ?>">
                                                                    <ul class="as-rating-list justify-content-center mt-0">
                                                                        <?php echo e(__($room->adult)); ?>

                                                                    </ul>
                                                                </td>
                                                                <td data-label="<?php echo app('translator')->get('Child'); ?>">
                                                                    <ul class="as-rating-list justify-content-center mt-0">
                                                                        <?php echo e(__($room->child)); ?>

                                                                    </ul>
                                                                </td>
                                                                <td data-label="<?php echo app('translator')->get('Price'); ?>">
                                                                    <span class="d-block">
                                                                        <?php echo e($general->cur_sym); ?><?php echo e(showAmount($room->price)); ?>

                                                                    </span>
                                                                </td>
                                                                <td data-label="<?php echo app('translator')->get('Select'); ?>">
                                                                    <div class="switch-button">
                                                                        <input type="checkbox" name="isSelectCheckbox[]" id="switch-label-<?php echo e($room->id); ?>" class="switch-button__checkbox isSelect"
                                                                        data-id="<?php echo e($room->id); ?>"
                                                                        data-room_number="<?php echo e($room->room_number); ?>"
                                                                        data-adult="<?php echo e($room->adult); ?>"
                                                                        data-child="<?php echo e($room->child); ?>"
                                                                        data-price="<?php echo e(showAmount($room->price)); ?>"
                                                                        >
                                                                        <label for="switch-label-<?php echo e($room->id); ?>" class="switch-button__label mb-0"></label>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mt-lg-0 mt-4">
                    <div class="hotel-details-sidebar">
                        <div class="selected-room">
                            <h5 class="selected-room__title mb-3"><?php echo app('translator')->get('Select Room Category'); ?></h5>
                            <form action="#" class="row g-3">
                                <div class="col-12">
                                    <select class="form-select form--select roomCategories">
                                        <?php $__currentLoopData = $roomCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php echo e($request->categoryId == $category->id ? 'selected':''); ?>

                                                    data-category="<?php echo e($category); ?>"
                                                ><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn selected-room__btn w-100">
                                       <?php echo app('translator')->get('Show Available Rooms'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                                                 
                            <div class="mt-4">
                                <ul class="area-list room-list-header">
                                    <li class="area-list__item d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="d-inline-block me-2">
                                                <i class="fas fa-hotel"></i>
                                            </span>
                                            <span class="d-inline-block fw-bold">
                                                <?php echo app('translator')->get('Room No.'); ?>
                                            </span>
                                        </div>
                                        <span class="d-inline-block fw-bold">
                                            <?php echo app('translator')->get('Price'); ?>
                                        </span>
                                    </li>
                                </ul>
                                <ul class="area-list room_list">
                                </ul>
                            </div>
                            <div class="mt-4">
                                <h5 class="selected-room__title mb-3 text-end"><?php echo app('translator')->get('Total'); ?></h5>
                                <ul class="area-list">
                                    <li class="area-list__item d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="d-inline-block me-2">
                                                <i class="fas fa-user-alt"></i>
                                            </span>
                                            <span class="d-inline-block sm-text">
                                                <?php echo app('translator')->get('Adult'); ?>
                                            </span>
                                        </div>
                                        <span class="d-inline-block sm-text selected_adult">
                                           <?php echo app('translator')->get('0'); ?>
                                        </span>
                                    </li>
                                    <li class="area-list__item d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="d-inline-block me-2">
                                                <i class="fas fa-child"></i>
                                            </span>
                                            <span class="d-inline-block sm-text">
                                                <?php echo app('translator')->get('Child'); ?>
                                            </span>
                                        </div>
                                        <span class="d-inline-block sm-text selected_child">
                                           <?php echo app('translator')->get('0'); ?>
                                        </span>
                                    </li>
                                    <li class="area-list__item d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="d-inline-block me-2">
                                                <i class="fas fa-receipt"></i>
                                            </span>
                                            <span class="d-inline-block sm-text">
                                                <?php echo app('translator')->get('Price'); ?>
                                            </span>
                                        </div>
                                        <span class="d-inline-block sm-text selected_total_price">
                                            <?php echo e($general->cur_sym); ?><?php echo app('translator')->get('0'); ?>
                                        </span>
                                    </li>
                                </ul>
                                <?php if($searchData && $searchData['date'] != null): ?>
                                    <div class="text-end mt-3">
                                        <form action="<?php echo e(route('user.property.booking')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="date" value="<?php echo e($searchData['date']); ?>">
                                            <input type="hidden" name="room_list">
                                            <button type="submit" class="btn btn-md btn--base w-100"><?php echo app('translator')->get('Pay Now'); ?></button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                     

                        <div class="mt-4">
                            <form action="<?php echo e(route('property.category.rooms.date', [$property->id, slug($property->name)])); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('Checkin - Checkout'); ?></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg--base text-white"><i class="las la-calendar-check"></i></span>
                                        <input type="text" data-range="true" name="date" data-multiple-dates-separator=" - "
                                            data-language="en" class="datepicker-here form--control" id="date"
                                            placeholder="Checkin & Checkout" autocomplete="off" value="<?php echo e(($searchData && $searchData['date'] != null) ? $searchData['date'] : ''); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Search'); ?></button>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- hotel deatils section end -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<script>
    (function ($) {
        "use strict";

        var curSym = '<?php echo e($general->cur_sym); ?>';

        <?php if(!$searchData || $searchData['date'] == null): ?>
          $('.datepicker-here').datepicker();
        <?php endif; ?>


        $(document).on('change', '.isSelect', function(){
            var totalPrice = 0;
            var totalAdult = 0;
            var totalChild = 0;
            var discountPrice = 0;
            var roomList = [];

            $('.selected_room_number').html('');
            $('.selected_adult').text('');
            $('.selected_child').text('');
            $('.selected_total_price').text('');
            $('.selected_discount_price').text('');
            $('[name=room_list]').val('');
            $('.room_list').html('');

            $("input:checkbox:checked").each(function (index) {
                var data = $(this).data();
                var roomPrice = parseFloat(data.price);
                totalPrice += roomPrice;
                discountPrice += parseFloat(data.discount_price);
                roomList.push(data.id);
                totalAdult += data.adult;
                totalChild += data.child;

                $('.room_list').append(`
                    <li class="area-list__item d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <span class="d-inline-block sm-text">
                                ${data.room_number}
                            </span>
                        </div>
                        <span class="d-inline-block sm-text">
                            ${curSym+roomPrice.toFixed(2)}
                        </span>
                    </li>
                `);

                $('.selected_room_number').append(index+1+'. '+data.room_number+'<br>');

                $('[name=room_list]').val(roomList);

            });

            $('.selected_adult').text(totalAdult);
            $('.selected_child').text(totalChild);
            $('.selected_total_price').text(curSym+totalPrice.toFixed(2));
            $('.selected_discount_price').text(curSym+discountPrice.toFixed(2));


        });

        $('.selected-room__btn').click(function(e){
            e.preventDefault();
        });

        $('.roomCategories').change(function(e){
            var category = $(this).find(':selected').data('category');
            $('.category-name').text(category.name);
            $('.amenity-list').text('');
            category.amenities.forEach(amenity => {
                $('.amenity-list').append(`<li class="amenity-list__item"><span class="amenity__icon">${amenity.icon}</span><span class="amenity__text">${amenity.name}</span></li>`);
            });
            var roomCategory = e.target.value;
            $('.category-item').css('display', 'none');
            $('.category-'+roomCategory).css('display', 'table-row');

        }).change();

    })(jQuery);

    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .room_list {
            border-top: none;
        }
        .room_list li:nth-child(odd) {
            background: #fff;
        }
        .room_list li:nth-child(even) {
            background: #f5f5f5;
        }
        .room-list-header {
            border-bottom: none;
            padding-bottom: 0;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/property/property_category_rooms.blade.php ENDPATH**/ ?>