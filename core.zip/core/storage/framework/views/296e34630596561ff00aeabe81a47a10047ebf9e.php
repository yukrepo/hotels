<?php
    $footer = getContent('footer.content', true);
    $contact = getContent('contact_us.content', true);
    $socials = getContent('social_icon.element');
    $policyPages = getContent('policy_pages.element');
?>
<footer class="footer bg_img" style="background-image: url('<?php echo e(getImage('assets/images/frontend/footer/'.$footer->data_values->background_image, '1920x840')); ?>');">
    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-4 col-sm-6 order-lg-1 order-1">
          <div class="footer-widget">
            <a href="<?php echo e(route('home')); ?>" class="footer-logo"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="image"></a>
            <p class="mt-3"><?php echo e(__($footer->data_values->short_description)); ?></p>
          </div>
        </div>
        <div class="col-lg-2 col-sm-6 order-lg-2 order-3">
          <div class="footer-widget">
            <h4 class="footer-widget__title"><span><?php echo app('translator')->get('Site Links'); ?></span></h4>
            <ul class="footer-menu-list">
              <li><a href="<?php echo e(route('property.search')); ?>"><?php echo app('translator')->get('Properties'); ?></a></li>
              <li><a href="<?php echo e(route('locations')); ?>"><?php echo app('translator')->get('Locations'); ?></a></li>
              <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('pages', $data->slug)); ?>"><?php echo e(__($data->name)); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li>
              <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-2 col-sm-6 order-lg-3 order-4">
          <div class="footer-widget">
            <h4 class="footer-widget__title"><span><?php echo app('translator')->get('Importants links'); ?></span></h4>
            <ul class="footer-menu-list">
              <?php $__currentLoopData = $policyPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policyPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                  <a href="<?php echo e(route('policy', [$policyPage, slug($policyPage->data_values->title)])); ?>">
                  <?php echo e(__($policyPage->data_values->title)); ?>

                  </a>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('user.register')); ?>"><?php echo app('translator')->get('User Registration'); ?></a></li>
              <li><a href="<?php echo e(route('owner.register')); ?>"><?php echo app('translator')->get('Owner Registration'); ?></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6 order-lg-4 order-2">
          <div class="footer-widget">
            <h4 class="footer-widget__title"><span><?php echo app('translator')->get('Contact Info'); ?></span></h4>
            <ul class="footer-contact-list">
              <li>
                <div class="icon">
                  <i class="las la-phone-volume"></i>
                </div>
                <div class="content"> 
                  <a href="tel:2454541544"><?php echo e(__($contact->data_values->contact_number)); ?></a>
                </div>
              </li>
              <li>
                <div class="icon">
                  <i class="las la-map-marker-alt"></i>
                </div>
                <div class="content"> 
                  <p><?php echo e(__($contact->data_values->contact_address)); ?></p>
                </div>
              </li>
              <li>
                <div class="icon">
                  <i class="las la-phone-volume"></i>
                </div>
                <div class="content"> 
                  <a href="mailto:demo@gmail.com"><?php echo e(__($contact->data_values->email_address)); ?></a>
                </div>
              </li>
              <li>
                <ul class="social-media-list d-flex flex-wrap align-items-center">
                  <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e($social->data_values->url); ?>" target="_blank"><?php echo $social->data_values->social_icon ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div><!-- row end -->
    </div>
    <div class="footer__bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 text-left col-12 col-sm-6">
            <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(__($general->sitename )); ?>. <?php echo app('translator')->get('All Right Reserved'); ?></p>
          </div>
          <div class="col-lg-6 col-12 col-sm-6">
            <p class="text-right"><?php echo e(__('Maintained By:')); ?> <a href="https://bluebrainbtech.com" target="_blank">Blue Brain Technologies</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>