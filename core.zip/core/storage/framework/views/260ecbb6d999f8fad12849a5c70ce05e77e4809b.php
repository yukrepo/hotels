<div class="tab-pane show active fade" id="hotel-location">
    <?php if($property->map_url): ?>
        <div class="hotel-details-box pt-4">
            <h3 class="title mb-4"><?php echo app('translator')->get('Location'); ?></h3>
            <div class="hotel-details-map">
                <iframe src="<?php echo e($property->map_url); ?>" allowfullscreen=""
                    loading="lazy"></iframe>
            </div>
        </div><!-- hotel-details-box end -->
    <?php endif; ?>
</div><?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/property/property_details_location.blade.php ENDPATH**/ ?>