<section class="inner-hero bg_img" style="background-image: url('<?php echo e(asset($activeTemplateTrue.'images/bg/hero14.jpg')); ?>');">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="page-title text-white"><?php echo e(__($pageTitle)); ?></h2>
        </div>
      </div>
    </div>
  </section><?php /**PATH /home/smarpgre/hotel.skydream.in/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>