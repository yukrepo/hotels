<div class="tab-pane show active fade" id="hotel-review">
    <div class="hotel-details-box border-bottom-0 py-4">
        <div class="row g-4 align-items-center">
            <div class="col-md-6">
                <div class="d-flex align-items-end">
                    <span class="d-inline-block as-rating"><?php echo e(showAmount($rating = $property->rating)); ?></span>
                    <span class="d-inline-block as-rating-divider">/</span>
                    <span class="d-inline-block as-rating-total"><?php echo app('translator')->get('5'); ?></span>
                </div>
                <ul class="as-rating-list">
                   <?php
                       echo ratingStar($rating)
                   ?>
                </ul>
                <span class="d-inline-block as-rating-text"><?php echo e(__($property->review)); ?> <?php echo app('translator')->get('Ratings'); ?></span>
            </div>
            <div class="col-md-6">
                <ul class="as-ratings">
                <?php for($i = 1; $i <= 5; $i++): ?>
                <li class="as-ratings__item">
                    <ul class="as-rating-list mt-0">
                        <?php for($j = 5; $j >= 1; $j--): ?>
                            <li class="as-rating-list__item">
                                <span class="as-rating-icon as-rating-icon--sm <?php if($i > $j): ?> as-rating-icon--disable <?php endif; ?>">
                                    <i class="fas fa-star"></i>
                                </span>
                            </li>
                        <?php endfor; ?>
                    </ul>
                    <div class="d-flex align-items-center">
                        <div class="progress rounded-0 flex-shrink-0 flex-grow-1 me-2" style="height: 10px;">
                            <div class="progress-bar bg--warning" role="progressbar" style="width: <?php echo e($property->review > 0 ? $reviewCount[6-$i] / ($reviewCount[6-$i] + $property->reviews->where('rating','!=', 6-$i)->count()) * 100 : 0); ?>%;"
                                aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <span class="d-inline-block as-rating-text mt-0"><?php echo e(__($reviewCount[6-$i])); ?></span>
                    </div>
                </li>
                <?php endfor; ?>
                </ul>
            </div>
        </div>
    </div><!-- hotel-details-box end -->
    <div class="py-2 border-bottom border-top">
        <small><?php echo app('translator')->get('Hotel Review'); ?></small>
    </div>
    <div class="review">
        <?php $__currentLoopData = $property->reviews->sortByDesc('id')->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3 py-3 border-bottom">
                <ul class="as-rating-list mt-0 user-rating">
                    <?php
                        echo ratingStar($review->rating)
                    ?>
                </ul>
                <small class="text-muted mb-3"><?php echo app('translator')->get('By '); ?> <?php echo e(__($review->user->fullname)); ?></small>
                <p class="sm-text">
                    <?php echo e(__($review->description)); ?>

                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if($property->reviews->count() > 10): ?>
        <div class="text-center">
            <button class="btn btn--base w-100 see-more"><?php echo app('translator')->get('See More'); ?></button>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('style'); ?>
    <style>
        .user-rating span{
            font-size: 14px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            let page = 10;
            let propertyId = `<?php echo e($property->id); ?>`;

            $('.see-more').on('click', function(){
                var url = `<?php echo e(route('property.review.load')); ?>`;
                var data = { '_token': '<?php echo e(csrf_token()); ?>', 'page': page, 'propertyId': propertyId};
                page += 10;
                $.ajax({
                type: "POST",
                url: url,
                data: data,
                success: function (response) {
                    $('.review').append(response);
                console.log(response);
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert("Status: " + textStatus); alert("Error: " + errorThrown);
                }

                });
            })

        })(jQuery);

    </script>
<?php $__env->stopPush(); ?><?php /**PATH /home/smarpgre/hotel.skydream.in/core/resources/views/templates/basic/property/property_details_reviews.blade.php ENDPATH**/ ?>