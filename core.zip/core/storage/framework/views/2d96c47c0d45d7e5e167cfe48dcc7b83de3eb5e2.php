<?php
$location = getContent('location.content', true);
$locations = \App\Models\Location::where('status', 1)->limit(10)->get();
?>


<!-- location section start -->
<section class="pt-100 pb-100 bg_img location-section" style="background-image: url('<?php echo e(getImage('assets/images/frontend/location/'.$location->data_values->background_image, '1920x1280')); ?>');">
    <div class="container-fluid">
      <div class="row justify-content-xl-end justify-content-center">
        <div class="col-xl-4 col-lg-6 col-md-8 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
          <div class="section-header text-xl-start text-center">
            <h2 class="section-title"><?php echo e(__($location->data_values->heading)); ?></h2>
            <p class="mt-3"><?php echo e(__($location->data_values->sub_heading)); ?></p>
            <a href="<?php echo e($location->data_values->button_url); ?>" class="btn btn--base mt-4"><?php echo e(__($location->data_values->button)); ?></a>
          </div>
        </div>
        <div class="col-xxl-7 col-xl-8 ps-3">
          <div class="location-slider">
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($location->image): ?>
            <div class="single-slide">
              <div class="location-card has--link rounded-3">
                <a href="<?php echo e(route('search.location.property', [$location->id, slug($location->name)])); ?>" class="item--link"></a>
                <img src="<?php echo e(getImage(imagePath()['location']['path'].'/'. $location->image, imagePath()['location']['size'])); ?>" alt="image">
                <div class="overlay-content">
                  <div class="top">
                  </div>
                  <div class="bottom">
                    <h4 class="location-name text-white"><?php echo e(__($location->name)); ?></h4>
                    <p class="text-white fs--14px"><?php echo app('translator')->get('Average price'); ?> <span class="float-end"><?php echo e($general->cur_sym); ?><?php echo e(showAmount($location->average_price)); ?></span></p>
                  </div>
                </div>
              </div><!-- location-card end -->
            </div><!-- single-slide end -->
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- location section end -->
<?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/sections/location.blade.php ENDPATH**/ ?>