
<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--md  table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('S.N.'); ?></th>
                                <th><?php echo app('translator')->get('Property Type'); ?></th>
                                <th><?php echo app('translator')->get('Property'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $propertyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('S.N.'); ?>"> <?php echo e($propertyTypes->firstItem() + $loop->index); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Property Type'); ?>"><?php echo e(__($propertyType->name)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Property'); ?>"><?php echo e($propertyType->properties->count()); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($propertyType->status == 1): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge--warning"><?php echo app('translator')->get('Inactive'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <button class="icon-btn editPropertyType"
                                            data-id="<?php echo e($propertyType->id); ?>" data-name="<?php echo e($propertyType->name); ?>"
                                            data-image="<?php echo e(getImage(imagePath()['property_type']['path'].'/'. $propertyType->image, imagePath()['property_type']['size'])); ?>"
                                            data-status="<?php echo e($propertyType->status); ?>">
                                            <i class="la la-pen"></i></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table><!-- table end -->
                </div>
            </div>
            <div class="card-footer py-4">
                <?php echo e(paginateLinks($propertyTypes)); ?>

            </div>
        </div>
    </div>
</div>



<div id="propertyTypeModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.type.property.store')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Name'); ?><span class="text-danger">*</span></label>
                            <div class="input-group has_append">
                                <input type="text" name="name" class="form-control"
                                    placeholder="<?php echo app('translator')->get('Enter your propertyType'); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="image"><?php echo app('translator')->get('Image'); ?></label>
                            <div class="oldImage">
                                <img src="" class="editImage">
                                <div class="text-center my-2">
                                    <button class="btn btn--danger btn-block btn-lg removeIt"><?php echo app('translator')->get('Remove It'); ?></button>
                                </div>
                            </div>
                            <div class="image-upload">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage('/', imagePath()['property_type']['size'])); ?>)">
                                            <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input type="file" class="profilePicUpload" name="image" id="locaton-image" accept=".png, .jpg, .jpeg">
                                        <label for="locaton-image" class="bg--success"><?php echo app('translator')->get('Upload Image'); ?></label>
                                        <small class="mt-2 text-facebook"><?php echo app('translator')->get('Supported files'); ?>: <b><?php echo app('translator')->get('jpeg'); ?>, <?php echo app('translator')->get('jpg'); ?>.</b> </small>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="old_image">
                        </div>
                        <div class="form-group statusGroup">
                            <label><?php echo app('translator')->get('Status'); ?></label>
                            <input type="checkbox" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle"
                                data-on="<?php echo app('translator')->get('Active'); ?>" data-off="<?php echo app('translator')->get('Inactive'); ?>" data-width="100%" name="status">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn--success"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <button type="button" class="btn btn-sm btn--primary box--shadow1 text--small addPropertyType" ><i class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?></button>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .image-upload .thumb .avatar-edit label{
            line-height: 35px;
            font-size: 14px;
        }
        .oldImage{
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.addPropertyType').click(function(){
                var modal = $('#propertyTypeModal');
                var action = `<?php echo e(route('admin.type.property.store')); ?>`;
                modal.find('.modal-title').text("<?php echo app('translator')->get('Add Property Type'); ?>");
                modal.find('.statusGroup').hide();
                $('.image-upload').css('display', 'block');
                modal.find('form').attr('action', action);
                modal.modal('show')
            });
            $('.editPropertyType').click(function () {
                var data = $(this).data();
                var modal = $('#propertyTypeModal');
                var action = `<?php echo e(route('admin.type.property.update', '')); ?>/${data.id}`;
                modal.find('.modal-title').text("<?php echo app('translator')->get('Update Property Type'); ?>");
                modal.find('.statusGroup').show();
                modal.find('[name=name]').val(data.name);
                if (data.status == 1) {
                    modal.find('[name=status]').bootstrapToggle('on');
                } else {
                    modal.find('[name=status]').bootstrapToggle('off');
                }

                modal.find('.editImage').attr('src', data.image);
                modal.find('[name=old_image]').val(data.image);

                $('.oldImage').css('display', 'block');
                $('.image-upload').css('display', 'none');

                modal.find('form').attr('action', action);
                modal.modal('show')
            });

            $('.removeIt').click(function(e){
                e.preventDefault();
                $('[name=old_image]').val('');
                $('.image-upload').css('display', 'block');
                $('.oldImage').css('display', 'none');
            });

            $('#propertyTypeModal').on('hidden.bs.modal', function () {
                $('#propertyTypeModal form')[0].reset();
                $('.oldImage').css('display', 'none');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/smarpgre/hotel.skydream.in/core/resources/views/admin/property_type/index.blade.php ENDPATH**/ ?>