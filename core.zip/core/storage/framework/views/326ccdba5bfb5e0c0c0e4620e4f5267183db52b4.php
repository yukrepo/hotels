<?php $__env->startSection('content'); ?>
<?php
    $banner = getContent('banner.content', true);
?>
<!-- hero section start -->
<section class="hero bg_img" style="background-image: url('<?php echo e(getImage('assets/images/frontend/banner/'.$banner->data_values->background_image, '1920x1195')); ?>');">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xxl-6 col-lg-8 text-center">
                <h2 class="hero__title text-white wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s"><?php echo e(__($banner->data_values->heading)); ?></h2>
                <p class="hero__description text-white mt-3 wow fadeInUp" data-wow-duration="0.5s"
                    data-wow-delay="0.5s"><?php echo e(__($banner->data_values->sub_heading)); ?></p>
            </div>
        </div>
    </div>
</section>
<section class="main-search-form">
    <div class="container">
        <div class="col-xxl-10 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.7s">
    <div class="hero-search-area rounded-3">
        <form action="<?php echo e(route('property.search')); ?>" class="hero-search-form">
            <div class="row gy-3 align-items-center">
                <div class="col-xl-3 col-lg-3 col-sm-6">
                    <label><?php echo app('translator')->get('Location'); ?></label>
                    <div class="input-group border px-2 radius-5">
                        <span class="input-group-text"><i class="las la-map-marker"></i></span>
                        <select class="select2-basic" name="location" id="location">
                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->id); ?>" <?php if(old('location') == $location->id): ?> selected="selected" <?php endif; ?>><?php echo e(__($location->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-sm-6">
                    <label><?php echo app('translator')->get('Checkin - Checkout'); ?></label>
                    <div class="input-group border px-2 radius-5">
                        <span class="input-group-text"><i class="las la-calendar-check"></i></span>
                        <input type="text" data-range="true" name="date" data-multiple-dates-separator=" - "
                            data-language="en" class="datepicker-here form--control" id="date"
                            placeholder="Checkin & Checkout" autocomplete="off" value="<?php echo e(old('date')); ?>">
                    </div>
                </div>
                <div class="col-xl-2 col-lg-2 col-sm-6">
                    <label><?php echo app('translator')->get('Adult'); ?></label>
                    <div class="input-group border px-2 radius-5">
                        <span class="input-group-text"><i class="las la-user"></i></span>
                        <input type="number" name="adult" autocomplete="off" value="<?php echo e(old('adult') ? old('adult') : 1); ?>" min="1" id="adult" class="form--control">
                    </div>
                </div>
                <div class="col-xl-2 col-lg-2 col-sm-6">
                    <label><?php echo app('translator')->get('Child'); ?></label>
                    <div class="input-group border px-2 radius-5">
                        <span class="input-group-text"><i class="las la-child"></i></span>
                        <input type="number" name="child" autocomplete="off" value="<?php echo e(old('child') ? old('child') : 0); ?>" min="0" id="child" class="form--control">
                    </div>
                </div>
                <div class="col-lg-2 text-end align-self-end">
                    <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Search'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>
    </div>
</section>
<!-- hero section end -->

<?php if($sections->secs != null): ?>
    <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/home.blade.php ENDPATH**/ ?>