
<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--md  table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('S.N.'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Property'); ?></th>
                                <th><?php echo app('translator')->get('Owner'); ?></th>
                                <th><?php echo app('translator')->get('Rooms'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $roomCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('S.N.'); ?>"> <?php echo e($roomCategories->firstItem() + $loop->index); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e(__($roomCategory->name)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Property'); ?>"><?php echo e(__($roomCategory->property->name)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Owner'); ?>"><?php echo e(__($roomCategory->property->owner->fullname)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Rooms'); ?>"><?php echo e(__($roomCategory->rooms->count())); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <a href="<?php echo e(route('admin.property.room.category.edit', $roomCategory->id)); ?>" class="icon-btn ml-1"><i class="la la-pen"></i></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table><!-- table end -->
                </div>
            </div>
            <div class="card-footer py-4">
                <?php echo e(paginateLinks($roomCategories)); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="<?php echo e(route('admin.property.room.category.create')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small" ><i class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?></a>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/smarpgre/hotel.skydream.in/core/resources/views/admin/room_category/index.blade.php ENDPATH**/ ?>