<?php
$trip = getContent('top_trip.content', true);
$properties = \App\Models\Property::with('location', 'rooms')
  ->whereHas('rooms', function($room){
    $room->where('status', 1);
  })
  ->orderBy('all_time_booked_counter', 'DESC')->limit(5)->get();
?>
<!-- best trip section start -->
<section class="pt-100 pb-100 bg_img best-trip-section" style="background-image: url('<?php echo e(getImage('assets/images/frontend/top_trip/'.$trip->data_values->background_image, '1920x1090')); ?>');">
  <div class="container-fluid">
    <div class="row justify-content-end">
      <div class="col-xxl-6 col-xl-7 pe-xl-5">
        <div class="section-header text-xl-start text-center">
          <h2 class="section-title"><?php echo e(__($trip->data_values->heading)); ?></h2>
          <p class="mt-2"><?php echo e(__($trip->data_values->sub_heading)); ?></p>
        </div>
        <div class="best-trip-slider">
          <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="single-slide">
            <div class="best-trip-card">
              <?php if($property->discount != 0): ?>
              <div class="best-trip-card__badge">
                <b><?php echo e(showAmount($property->discount)); ?>%</b> <br>
                <span><?php echo app('translator')->get('off'); ?></span>
              </div>
              <?php endif; ?>
              <div class="thumb">
                <img src="<?php echo e(getImage(imagePath()['property']['path'].'/'. $property->image, imagePath()['property']['size'])); ?>" alt="image">
              </div>
              <div class="content">
                <div class="top">
                  <div class="ratings">
                    <?php for($i = 0; $i < round($property->rating); $i++): ?>
                    <i class="las la-star"></i>
                    <?php endfor; ?>
                      <span class="fs--14px">(<?php echo e($property->review); ?>)</span>
                  </div>
                  <h4 class="name"><?php echo e(__($property->name)); ?></h4>
                  <span class="fs--14px mt-2"><i class="las la-map-marked-alt fs--18px"></i> <?php echo app('translator')->get('in'); ?> <?php echo e(__($property->location->name)); ?></span>
                </div>
                <div class="bottom d-flex align-items-center">
                  <div class="col-6">
                    <div class="price text--base">
                      <?php
                        $lowestPrice = $property->rooms[0]->price;
                          foreach ($property->rooms as $room) {
                            if($room->price < $lowestPrice){
                              $lowestPrice = $room->price;
                            }
                          }
                          echo $general->cur_sym.showAmount($lowestPrice);
                      ?>
                    </div>
                    <span class="fs--14px"><?php echo app('translator')->get('Per night'); ?></span>
                  </div>
                  <div class="col-6 text-end">
                    <a href="<?php echo e(route('property', [$property->id, slug($property->name)])); ?>" class="btn btn-sm btn--base"><?php echo app('translator')->get('View Details'); ?></a>
                  </div>
                </div>
              </div>
            </div><!-- best-trip-card end -->
          </div><!-- single-slide end -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div>
</section>
<!-- best trip section end -->
<?php /**PATH D:\xampp\htdocs\hotel\core\resources\views/templates/basic/sections/top_trip.blade.php ENDPATH**/ ?>