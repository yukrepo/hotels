@extends($activeTemplate.'layouts.frontend')
@section('content')
    <!-- hotel deatils section start -->
    <section class="pb-100">
        <div class="hotel-details-thumb-slider">
            <div class="single-slide">
                <div class="hotel-details-thumb">
                    <a href="{{ getImage(imagePath()['property']['path'] . '/' . $property->image, imagePath()['property']['size']) }}"
                        class="lightcase full-view" data-rel="lightcase"><i class="las la-image"></i>@lang('See Full View')
                    </a>
                    <img src="{{ getImage(imagePath()['property']['path'] . '/' . $property->image, imagePath()['property']['size']) }}"
                        alt="image">
                </div>
            </div><!-- single-slide end -->
            @foreach ($property->images as $image)
                <div class="single-slide">
                    <div class="hotel-details-thumb">
                        <a href="{{ getImage(imagePath()['property']['path'] . '/' . $image, imagePath()['property']['size']) }}"
                            class="lightcase full-view" data-rel="lightcase"><i class="las la-image"></i>@lang('See Full
                            View')
                        </a>
                        <img src="{{ getImage(imagePath()['property']['path'] . '/' . $image, imagePath()['property']['size']) }}"
                            alt="image">
                    </div>
                </div><!-- single-slide end -->
            @endforeach
        </div><!-- hotel-details-thumb-slider end -->
        <div class="container pt-50">
            <div class="row">
                <div class="col-lg-8">

                    <ul class="nav hotel-nav">
                        <li class="hotel-nav__item">
                            <button class="nav-link w-100 active hotel-nav__btn">@lang('Amenities')</button>
                        </li>
                    </ul>
                    @include($activeTemplate.'property.property_details_rooms')

                    <ul class="nav hotel-nav mt-4">
                        <li class="hotel-nav__item">
                            <button class="nav-link w-100 active hotel-nav__btn">@lang('Description')</button>
                        </li>
                    </ul>
                    @include($activeTemplate.'property.property_details_description')

                    <ul class="nav hotel-nav mt-4">
                        <li class="hotel-nav__item">
                            <button class="nav-link w-100 active hotel-nav__btn">@lang('Location')</button>
                        </li>
                    </ul>
                    @include($activeTemplate.'property.property_details_location')

                    <ul class="nav hotel-nav mt-4">
                        <li class="hotel-nav__item">
                            <button class="nav-link w-100 active hotel-nav__btn">@lang('Review')</button>
                        </li>
                    </ul>
                    @include($activeTemplate.'property.property_details_reviews')

                    <ul class="nav hotel-nav mt-4">
                        <li class="hotel-nav__item">
                            <button class="nav-link w-100 active hotel-nav__btn">@lang('Hotel Policy')</button>
                        </li>
                    </ul>

                    {!!$property->hotel_policy!!}

                    <ul class="nav hotel-nav mt-4">
                        <li class="hotel-nav__item">
                            <button class="nav-link w-100 active hotel-nav__btn">@lang('Cancellation Policy')</button>
                        </li>
                    </ul>

                    {!!$property->cancellation_policy!!}
                </div>
                <div class="col-lg-4 mt-lg-0 mt-4">
                    <div class="hotel-details-sidebar">
                        <div class="reserve-widget">
                            <div class="top text-center">
                                @if ($property->discount != 0)
                                    <div class="hotel-details-offer-badge">
                                        <b>{{ $property->discount }}%</b> <br>
                                        <span>@lang('off')</span>
                                    </div>
                                @endif
                                <h4>{{ $property->star }} @lang('star hotel')</h4>
                                @if (count($property->rooms))
                                    <div class="price">
                                        @if ($property->discount != 0)
                                            <del>{{ $general->cur_sym }} {{ showAmount($lowestRoomPrice) }}</del>
                                            <span
                                                class="text--base">{{ $general->cur_sym }}{{ showAmount(($lowestRoomPrice * (100 - $property->discount)) / 100) }}</span>
                                            <h6>/ @lang('per night')</h6>
                                        @else
                                            <span class="text--base">{{ $general->cur_sym }}
                                                {{ showAmount($lowestRoomPrice) }}</span>
                                        @endif
                                    </div>
                                @else
                                    <p>@lang('No room found')</p>
                                @endif
                                <hr>
                                <div class="form-check">
                                  <label class="form-check-label">
                                    <input type="radio" class="form-check-input" value="3" name="hour">3 Hour<span style="margin-left: 120px;">500 INR</span>
                                  </label>
                                </div>
                                <div class="form-check">
                                  <label class="form-check-label">
                                    <input type="radio" class="form-check-input" value="6" name="hour">6 Hour<span style="margin-left: 120px;">1000 INR</span>
                                  </label>
                                </div>
                                <div class="form-check">
                                  <label class="form-check-label">
                                    <input type="radio" class="form-check-input" value="12" name="hour">12 Hour<span style="margin-left: 120px;">2000 INR</span>
                                  </label>
                                </div>
                            </div>
                            @if (isset($request))
                                @if ($request->location && $request->date && $request->adult)
                                    <form action="{{ route('property.rooms') }}">
                                        <input type="hidden" name="property" value="{{ $property->id }}">
                                        <input type="hidden" name="location" value="{{ $request->location }}">
                                        <input type="hidden" name="date" value="{{ $request->date }}">
                                        <input type="hidden" name="adult" value="{{ $request->adult }}">
                                        <input type="hidden" name="child" value="{{ $request->child }}">
                                    </form>
                                @else
                                    <form action="{{ route('property.rooms') }}">
                                        <input type="hidden" name="property" value="{{ $property->id }}">
                                        <input type="hidden" name="location" value="{{ $request->location }}">
                                        <input type="hidden" name="date" value="{{ $request->date }}">
                                        <input type="hidden" name="adult" value="{{ $request->adult }}">
                                        <input type="hidden" name="child" value="{{ $request->child }}">
                                        <button type="submit" class="btn btn--base w-100 mt-4">@lang('Sell All
                                            Rooms')</button>
                                    </form>
                                @endif
                            @endif
                        </div>
                        <div class="book-widget mt-4 text-center text-white">
                            <i class="las la-phone-volume"></i>
                            <h3 class="text-white mt-2">@lang('Book by phone')</h3>
                            <a href="tel:45455" class="fs--18px text--base mt-3 mb-1">{{ $property->phone }}</a>
                            <p class="text-white fs--14px">{{ $property->phone_call_time }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- hotel deatils section end -->
@endsection
