<div class="tab-pane show active fade" id="hotel-category">
    <div class="hotel-details-box pt-4">
        @foreach ($property->roomCategories as $roomCategory)
            <!-- <h5>{{$roomCategory->name}}</h5> -->
            <ul class="amenity-list">
            @foreach ($roomCategory->amenities as $amenity)
                <li class="amenity-list__item"><span class="amenity__icon">{!! __($amenity->icon) !!}</span><span class="amenity__text">{{ __($amenity->name) }}</span></li>
            @endforeach
            </ul>
        @endforeach
        <a href="{{ route('property.category.rooms', [$property->id, slug($property->name), $roomCategory->id]) }}" class="btn btn-sm btn--danger w-100 mt-4">@lang('Check Room Details')</a>
    </div><!-- hotel-details-box end -->
</div>