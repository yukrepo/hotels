<section class="inner-hero bg_img" style="background-image: url('{{ asset($activeTemplateTrue.'images/bg/hero14.jpg') }}');">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="page-title text-white">{{ __($pageTitle) }}</h2>
        </div>
      </div>
    </div>
  </section>