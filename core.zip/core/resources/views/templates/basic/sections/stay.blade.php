@php
$stay = getContent('stay.content', true);
@endphp


<!-- location section start -->
<section class="pt-50 bg_img" style="background-image: url('{{ getImage('assets/images/frontend/stay/'.$stay->data_values->background_image, '1920x1280') }}'); background-size: cover;">
    <div class="container-fluid">
      <div class="row justify-content-start">
        <div class="col-xl-6 col-lg-6 col-md-6 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
          <div class="section-header">
            <h3 class="">{{ __($stay->data_values->heading) }}</h3>
            <p class="mt-3">{!! __($stay->data_values->description_nic) !!}</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- location section end -->