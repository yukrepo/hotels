@php
$milestone = getContent('milestone.content', true);
@endphp


<!-- location section start -->
<section class="pt-100 pb-50" style="background-image: url('{{ getImage('assets/images/frontend/milestone/'.$milestone->data_values->background_image, '1920x1280') }}');">
    <div class="container">
      <div class="row justify-content-xl-end justify-content-center">
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
          <div class="section-header text-center">
            <h2 class="section-title">{{ __($milestone->data_values->years) }}+</h2>
            <h3 style="font-weight: 400;">Amazing Year</h3>
          </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
          <div class="section-header text-center">
            <h2 class="section-title">{{ __($milestone->data_values->cities) }}+</h2>
            <h3 style="font-weight: 400;">Cities</h3>
          </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
          <div class="section-header text-center">
            <h2 class="section-title">{{ __($milestone->data_values->hotels) }}+</h2>
            <h3 style="font-weight: 400;">Hotels</h3>
          </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
          <div class="section-header text-center">
            <h2 class="section-title">{{ __($milestone->data_values->customers) }}+</h2>
            <h3 style="font-weight: 400;">Customers</h3>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- location section end -->
