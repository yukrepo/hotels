@php echo  $body @endphp
